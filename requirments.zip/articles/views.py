from django.shortcuts import redirect, render
from .models import Articles
from django.contrib import messages
# Create your views here.
def home_view(request):
    object_list = Articles.objects.all()
    context = {
        'object_list':object_list
    }
    return render(request, 'articles/index.html', context)
def detail_view(request, pk):
    obj = Articles.objects.get(id=pk)
    context = {
        'object' : obj
    }
    return render(request, 'articles/detail.html', context)
def search_article(request):
    obj = None
    if request.method == "POST":
        query = request.POST.get('qy')
        try:
            obj = Articles.objects.filter(title__icontains = query) 
        except:
            print(33333)
            messages.error(request, 'siz qidirgan article chiqmadi !!')
            redirect('/articles/search')
    context = {
            'object':obj
        }
    return render(request, 'articles/search.html', context)

def create_article(request):
    if request.method == "POST":
        title = request.POST.get('title')
        content = request.POST.get('content')
        if title and content :
            obj = Articles.objects.create(title = title, content = content)
        else:
            messages.error(request, 'siz qidirgan article chiqmadi !!')
            redirect('/articles/search')
    
    return render(request, 'articles/create.html', {})
