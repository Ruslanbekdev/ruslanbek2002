from django.urls import path
from .views import home_view, detail_view, search_article, create_article
urlpatterns = [
    path('',home_view, name='base'),
    path('<int:pk>/', detail_view, name='index'),
    path('search/', search_article, name='search'),
    path('create/', create_article, name = 'create'),
    
]
