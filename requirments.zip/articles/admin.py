from dataclasses import fields
from re import search
from django.contrib import admin
from .models import Articles
# Register your models here.
class ArticleAdmin(admin.ModelAdmin):
     list_display = ['title', 'content', 'time', 'id', 'last_update', 'created_at']
     search_fields = ['id', 'title', 'content']
     fields = ['id', 'last_update', 'created_at']
     list_filter = ['created_at']
admin.site.register(Articles,ArticleAdmin)
