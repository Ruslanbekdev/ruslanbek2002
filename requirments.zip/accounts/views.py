from django.shortcuts import redirect, render
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout

# Create your views here.
def login_view(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')

        print('user: ', username)
        print('passw: ', password)
        user = authenticate(username=username, password=password)
        if user is None:
            messages.error(request, 'username yoki parol xato')
            return redirect('login-view')
        login(request, user)
        return redirect('/articles')
    return render(request, 'accounts/login.html', {})
def log_out(request):
    if request.method == "POST":
        logout(request)
        return redirect('/login')
    return render(request, "accounts/logout.html" , {})
        