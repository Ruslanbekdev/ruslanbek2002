from django.urls import path
from .views import login_view, log_out

urlpatterns = [
    path('login/', login_view, name='login-view'),
    path('logout/', log_out, name='log_out')
]
